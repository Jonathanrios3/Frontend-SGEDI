'use strict';

angular.module('startUpApp.util', []);
